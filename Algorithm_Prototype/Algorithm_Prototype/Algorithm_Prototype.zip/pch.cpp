// pch.cpp: Quelldatei, die dem vorkompilierten Header entspricht. Diese ist für eine erfolgreiche Kompilierung erforderlich.

#include "pch.h"

// Im Allgemeinen ignorieren Sie diese Datei, aber heben sie auf, wenn Sie vorkompilierte Header verwenden.
