#include "pch.h"
#include "Preprocessor_BestWay.h"

// Default Constructor
Preprocessor_BestWay::Preprocessor_BestWay() {};


unsigned int Preprocessor_BestWay::get_costAsReference() {
	return this->costAsReference;
}