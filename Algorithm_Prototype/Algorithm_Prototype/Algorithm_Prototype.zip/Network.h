#ifndef _NETWORK_
#define _NETWORK_

#include <string>
using namespace::std;

//City Def:
/*
0: K�ln
1: Berlin
2: Rostock
3: Schwerin
4: Frankfurt
5: M�nchen
6: Friedrichshafen
*/

const int maxCitys = 7;
static string citys[maxCitys] = { "Koeln", "Berlin", "Rostock", "Schwerin", "Frankfurt", "Muenchen", "Friedrichshafen"};

#endif